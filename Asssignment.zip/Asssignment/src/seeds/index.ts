import { Seed } from '../core/modules/seeder/seeder.dto';

const seeds: Seed[] = [];

export default seeds;
