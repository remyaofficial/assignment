import { Controller } from '@nestjs/common';

@Controller('vehicle')
export class VehicleController {}
